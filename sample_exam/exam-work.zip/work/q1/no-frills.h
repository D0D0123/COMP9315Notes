// COMP9315 22T1 Final Exam
// Definitions for no-frills data files

// how many bytes in a page
#define PAGESIZE 512

// maximum size of tuples (including '\0')
#define MAXTUPLEN 100

