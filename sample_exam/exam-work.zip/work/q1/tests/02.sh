./q1 data/Data1
