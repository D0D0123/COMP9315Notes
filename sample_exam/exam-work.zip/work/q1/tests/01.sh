./q1  data/Data0
