./q1 data/Data3
