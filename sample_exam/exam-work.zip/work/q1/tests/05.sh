./q1 data/Data4
