./q3 myData4 data/input2000
diff myData4 data/Data4
