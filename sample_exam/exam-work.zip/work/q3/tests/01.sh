./q3 myData0 data/input0
diff myData0 data/Data0
