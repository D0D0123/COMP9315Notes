./q3 myData3 data/input1000
diff myData3 data/Data3
