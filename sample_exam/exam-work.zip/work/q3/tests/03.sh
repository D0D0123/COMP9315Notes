./q3 myData2 data/input200
diff myData2 data/Data2
