./q3 myData1 data/input20
diff myData1 data/Data1
