./q2 data/Data6
