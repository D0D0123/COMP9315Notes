./q2 data/Data0
