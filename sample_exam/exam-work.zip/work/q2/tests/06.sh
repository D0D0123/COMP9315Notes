./q2 data/Data5
