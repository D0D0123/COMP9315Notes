./q2 data/Data1
